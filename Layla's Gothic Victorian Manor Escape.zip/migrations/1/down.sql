
DROP INDEX idx_puzzles_stage;
DROP INDEX idx_user_progress_user_id;
DROP TABLE user_progress;
DROP TABLE puzzles;
